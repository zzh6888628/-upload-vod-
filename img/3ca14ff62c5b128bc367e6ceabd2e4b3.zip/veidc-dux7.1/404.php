<?php get_header(); ?>

<?php get_template_part( 'content-404' ); ?>

<?php get_footer(); ?>