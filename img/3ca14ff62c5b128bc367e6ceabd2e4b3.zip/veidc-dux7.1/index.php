<?php 
	get_header(); 
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
?>
<section class="container">
	<div class="content-wrap">
	<div class="content">
		<?php 
			if( $paged<=1 && _hui('focusslide_s') ){ 
				_moloader('mo_slider', false);
				mo_slider('focusslide');
			} 
		?>
		<?php  
			if( $paged<=1 && ((!wp_is_mobile() && _hui('topics_at_home', 1)) || (wp_is_mobile() && _hui('topics_at_home_m', 1))) ){
				_moloader('mo_topics');
			}
		?>
       		          <!--首页5栏-->	
          <div class="asb asb-indexd asb-indexd-01"><div class="container">
          <ul class="eboxx">
               <li class="eboxx-i eboxx-01"><img src='https://www.veidc.com//wp-content/uploads/2019/09/5-120601154100.gif' />
               <h4><font color="c35bff"><strong> Hostwinds-免费更换IP </strong></font></h4>
               <h4><font color="c35bff"><strong> （月付4.49美元起） </strong></font></h4>
               <p><font color="555555">老牌大厂，国内用户首选西雅图机房，支持支付宝！</font></p>
               <a class="btn btn-sm btn-primary" target="_blank" href="https://www.veidc.com/recommends/hostwinds">点击查看</a>
               </li>
               <li class="eboxx-i eboxx-02"><img src='https://www.veidc.com//wp-content/uploads/2019/09/5-120601154100.gif' />
               <h4><font color="ff5e52"><strong> Contabo-德国老牌商家</strong></font></h4>
               <h4><font color="ff5e52"><strong>（高配低价，3.99欧）</strong></font></h4>
               <p><font color="555555">超过17年的欧洲老牌商家！可选美国、欧洲数据中心！</font></p>
               <a class="btn btn-sm btn-danger" target="_blank" href="/recommends/contabo-vps">点击查看</a>
               </li>
               <li class="eboxx-i eboxx-03"><img src='https://www.veidc.com//wp-content/uploads/2019/09/5-120601154100.gif' />
               <h4><font color="c35bff"><strong> 搬瓦工-最强CN2 GIA </strong></font></h4>
               <h4><font color="c35bff"><strong>（稳定高品质）</strong></font></h4>
               <p><font color="555555">全系KVM架构，线路稳定，国人购买最多的商家！</font></p>
               <a class="btn btn-sm btn-primary" href="/recommends/bwh88" target="_blank" rel="nofollow noopener noreferrer">点击查看</a>
               </li>
               <li class="eboxx-i eboxx-03"><img src='https://www.veidc.com//wp-content/uploads/2019/09/5-120601154100.gif' />
               <h4><font color="ff5e52"><strong> 香港-台湾CN2 GIA 独服 </strong></font></h4>
               <h4><font color="ff5e52"><strong>（110M大带宽799起）</strong></font></h4>
               <p><font color="555555">香港高速CN2混合大带宽，免备案，限量促销</font></p>
               <a class="btn btn-sm btn-primary" href="https://www.iaodun.com/index.php?rp=/store/hk-100m-dedicated" target="_blank" rel="nofollow noopener noreferrer">点击查看</a>
              </li>
            </ul>
          </div></div> 
       
		<?php 
			$pagedtext = ''; 
			if( $paged > 1 ){
				$pagedtext = ' <small>第'.$paged.'页</small>';
			}
		?>
		<?php  
			if( $paged<=1 && _hui('minicat_home_s') ){
				_moloader('mo_minicat');
			}
		?>
		<?php _the_ads($name='ads_index_01', $class='orbui-index orbui-index-01') ?>
		<?php if( _hui('index_list_title') ){ ?>
		<div class="title">
			<h3>
				<?php echo _hui('index_list_title') ?>
				<?php echo $pagedtext ?>
			</h3>
			<?php 
				if( _hui('index_list_title_r') ){
					echo '<div class="more">'._hui('index_list_title_r').'</div>';
				} 
			?>
		</div>
		<?php } ?>
		<?php 
			global $sticky_ids;
			$pagedefaultnums = get_option( 'posts_per_page', 10 );
			$pagenums        = $pagedefaultnums;
			$offset_nums     = 0;
			$sticky_nums     = 0;
			$sticky_ids      = get_option('sticky_posts');

			if( _hui('home_sticky_s') && $sticky_ids && _hui('home_sticky_n') && in_array(_hui('home_sticky_n'), array('1','2','3','4','5')) ){

				rsort( $sticky_ids );

	            $sticky_nums = count($sticky_ids);

	            if( $sticky_nums > _hui('home_sticky_n') ){
	                $sticky_nums = _hui('home_sticky_n');

	                $sticky_ids = array();
	                $args = array(
						'post__in'            => $sticky_ids,
						'posts_per_page'      => $sticky_nums,
						'ignore_sticky_posts' => 0
					);
					query_posts($args);
					while ( have_posts() ) : the_post(); 
						$sticky_ids[] = get_the_ID();
					endwhile; 
					wp_reset_query();

					$sticky_ids = array_slice($sticky_ids, 0, $sticky_nums);
	            }

				if( $paged <= 1 ){
					$args = array(
						'post__in'            => $sticky_ids,
						'posts_per_page'      => $sticky_nums,
						'ignore_sticky_posts' => 1
					);
					query_posts($args);
					get_template_part( 'excerpt' );
					wp_reset_query();

					$pagenums = $pagenums-$sticky_nums;
				}else{
					$offset_nums = $sticky_nums;
				}
			}


			$args = array(
				'post__not_in'        => array(),
				'posts_per_page'      => $pagenums,
				'paged'               => $paged,
				'ignore_sticky_posts' => 1
	        );

	        if( $offset_nums ){
	            $args['offset'] = $pagenums*($paged-1) - $offset_nums;
	        }

	        if( _hui('notinhome_post') ){
				$args['post__not_in'] = explode("\n", _hui('notinhome_post'));
			}

	        if( _hui('home_sticky_s') && $sticky_ids ){
	            $args['post__not_in'] = array_unique(array_merge($sticky_ids,$args['post__not_in']));
	        }

	        if( _hui('notinhome') ){
	            $pool = array();
	            foreach (_hui('notinhome') as $key => $value) {
	                if( $value ) $pool[] = $key;
	            }
	            if( $pool ) $args['cat'] = '-'.implode($pool, ',-');
	        }

			query_posts($args);
			get_template_part( 'excerpt' ); 
			if( _hui('home_sticky_s') && $sticky_ids ){
				$wp_query->max_num_pages = ceil( ($wp_query->found_posts+$sticky_nums) / $pagedefaultnums );
			}
			_moloader('mo_paging');
			wp_reset_query();
		?>
		<?php _the_ads($name='ads_index_02', $class='orbui-index orbui-index-02') ?>
	</div>
	</div>
	<?php get_sidebar(); ?>
</section>
<?php get_footer();